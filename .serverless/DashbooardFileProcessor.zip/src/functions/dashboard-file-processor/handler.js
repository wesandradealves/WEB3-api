/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 634:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TransferStatusEnum = void 0;
var TransferStatusEnum;
(function (TransferStatusEnum) {
    TransferStatusEnum["PENDING"] = "PENDING";
    TransferStatusEnum["COMPLETED"] = "COMPLETED";
    TransferStatusEnum["FAILED"] = "FAILED";
})(TransferStatusEnum || (exports.TransferStatusEnum = TransferStatusEnum = {}));


/***/ }),

/***/ 897:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadedFileEnum = void 0;
var UploadedFileEnum;
(function (UploadedFileEnum) {
    UploadedFileEnum["UPLOADED"] = "UPLOADED";
    UploadedFileEnum["PROCESSING"] = "PROCESSING";
    UploadedFileEnum["PROCESSED"] = "PROCESSED";
})(UploadedFileEnum || (exports.UploadedFileEnum = UploadedFileEnum = {}));


/***/ }),

/***/ 782:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BaseEntity = void 0;
const typeorm_1 = __webpack_require__(132);
class BaseEntity {
}
exports.BaseEntity = BaseEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], BaseEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at', type: 'timestamp' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], BaseEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at', type: 'timestamp' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], BaseEntity.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.DeleteDateColumn)({ name: 'deleted_at', type: 'timestamp', nullable: true }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], BaseEntity.prototype, "deletedAt", void 0);


/***/ }),

/***/ 54:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DashboardTransferList = void 0;
const typeorm_1 = __webpack_require__(132);
const base_entity_1 = __webpack_require__(782);
const uploaded_files_entity_1 = __webpack_require__(515);
const transfer_status_enum_1 = __webpack_require__(634);
let DashboardTransferList = class DashboardTransferList extends base_entity_1.BaseEntity {
};
exports.DashboardTransferList = DashboardTransferList;
__decorate([
    (0, typeorm_1.ManyToOne)(() => uploaded_files_entity_1.UploadedFiles, (updateFile) => updateFile.id, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'uploaded_file_id' }),
    __metadata("design:type", typeof (_a = typeof uploaded_files_entity_1.UploadedFiles !== "undefined" && uploaded_files_entity_1.UploadedFiles) === "function" ? _a : Object)
], DashboardTransferList.prototype, "updateFile", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_file_id', type: 'uuid' }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "updateFileId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "asset", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "wallet", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2 }),
    __metadata("design:type", Number)
], DashboardTransferList.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "obs", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "enum",
        enum: transfer_status_enum_1.TransferStatusEnum,
        default: transfer_status_enum_1.TransferStatusEnum.PENDING,
    }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "status", void 0);
exports.DashboardTransferList = DashboardTransferList = __decorate([
    (0, typeorm_1.Entity)('transfer_assets')
], DashboardTransferList);


/***/ }),

/***/ 515:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadedFiles = void 0;
const typeorm_1 = __webpack_require__(132);
const base_entity_1 = __webpack_require__(782);
const uploaded_file_enum_1 = __webpack_require__(897);
let UploadedFiles = class UploadedFiles extends base_entity_1.BaseEntity {
};
exports.UploadedFiles = UploadedFiles;
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], UploadedFiles.prototype, "link", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "enum",
        enum: uploaded_file_enum_1.UploadedFileEnum,
        default: uploaded_file_enum_1.UploadedFileEnum.UPLOADED,
    }),
    __metadata("design:type", String)
], UploadedFiles.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_id' }),
    __metadata("design:type", String)
], UploadedFiles.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], UploadedFiles.prototype, "hash", void 0);
exports.UploadedFiles = UploadedFiles = __decorate([
    (0, typeorm_1.Entity)('uploaded_files')
], UploadedFiles);


/***/ }),

/***/ 56:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IDashboardFileProcessorRepository = void 0;
exports.IDashboardFileProcessorRepository = Symbol('IDashboardFileProcessorRepository');


/***/ }),

/***/ 205:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DashboardFileProcessorModule = void 0;
const transfer_assets_entity_1 = __webpack_require__(54);
const uploaded_files_entity_1 = __webpack_require__(515);
const dashboard_file_processor_repository_1 = __webpack_require__(56);
const database_module_1 = __webpack_require__(207);
const s3_external_1 = __webpack_require__(703);
const dashboard_file_processor_repository_2 = __webpack_require__(674);
const common_1 = __webpack_require__(563);
const typeorm_1 = __webpack_require__(522);
let DashboardFileProcessorModule = class DashboardFileProcessorModule {
};
exports.DashboardFileProcessorModule = DashboardFileProcessorModule;
exports.DashboardFileProcessorModule = DashboardFileProcessorModule = __decorate([
    (0, common_1.Module)({
        imports: [
            database_module_1.DataBaseModule,
            typeorm_1.TypeOrmModule.forFeature([uploaded_files_entity_1.UploadedFiles, transfer_assets_entity_1.DashboardTransferList]),
        ],
        providers: [
            s3_external_1.S3External,
            {
                provide: dashboard_file_processor_repository_1.IDashboardFileProcessorRepository,
                useClass: dashboard_file_processor_repository_2.DashboardFileProcessor,
            },
        ],
    })
], DashboardFileProcessorModule);


/***/ }),

/***/ 451:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dataSourceMigrations = exports.dataSourceDashBoard = void 0;
const dotenv = __webpack_require__(818);
const typeorm_1 = __webpack_require__(132);
dotenv.config();
exports.dataSourceDashBoard = {
    type: process.env.DATABASE_TYPE,
    host: process.env.DATABASE_HOST,
    port: process.env.DATABASE_PORT,
    username: process.env.DATABASE_USERNAME,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
    ssl: false,
    entities: ['dist/domain/entities/**/*.entity{.ts,.js}'],
    synchronize: false,
};
const datasourceMigrations = async () => {
    return new typeorm_1.DataSource({
        ...exports.dataSourceDashBoard,
        ssl: false,
        migrations: ['dist/infrastructure/database/migrations/*.{js,ts}'],
        entities: ['src/domain/entities/**/*.entity{.ts,.js}'],
        synchronize: false,
    });
};
exports.dataSourceMigrations = datasourceMigrations();


/***/ }),

/***/ 207:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DataBaseModule = void 0;
const common_1 = __webpack_require__(563);
const typeorm_1 = __webpack_require__(522);
const postgres_provider_1 = __webpack_require__(451);
let DataBaseModule = class DataBaseModule {
};
exports.DataBaseModule = DataBaseModule;
exports.DataBaseModule = DataBaseModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forRootAsync({
                useFactory: () => Object.assign(postgres_provider_1.dataSourceDashBoard, { autoLoadEntities: true }),
            }),
        ],
        exports: [],
    })
], DataBaseModule);


/***/ }),

/***/ 703:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.S3External = void 0;
const common_1 = __webpack_require__(563);
const client_s3_1 = __webpack_require__(43);
const stream_1 = __webpack_require__(203);
let S3External = class S3External {
    constructor() {
        this.s3Client = new client_s3_1.S3Client({
            region: "us-east-2",
            credentials: {
                accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
            },
        });
    }
    async downloadFile(s3Url) {
        const { Bucket, Key } = this.parseS3Url(s3Url);
        const command = new client_s3_1.GetObjectCommand({ Bucket, Key });
        const response = await this.s3Client.send(command);
        if (!response.Body || !(response.Body instanceof stream_1.Readable)) {
            throw new Error("Failed to download file from S3");
        }
        return response.Body;
    }
    parseS3Url(s3Url) {
        let bucket;
        let key;
        if (s3Url.startsWith("s3://")) {
            const match = s3Url.match(/^s3:\/\/([^/]+)\/(.+)$/);
            if (!match) {
                throw new Error(`Invalid S3 URL: ${s3Url}`);
            }
            bucket = match[1];
            key = match[2];
        }
        else if (s3Url.startsWith("http://") || s3Url.startsWith("https://")) {
            const url = new URL(s3Url);
            bucket = url.hostname.split(".")[0];
            key = url.pathname.substring(1);
        }
        else {
            throw new Error(`Invalid S3 URL: ${s3Url}`);
        }
        return { Bucket: bucket, Key: key };
    }
};
exports.S3External = S3External;
exports.S3External = S3External = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], S3External);


/***/ }),

/***/ 674:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DashboardFileProcessor = void 0;
const uploaded_files_entity_1 = __webpack_require__(515);
const common_1 = __webpack_require__(563);
const typeorm_1 = __webpack_require__(522);
const typeorm_2 = __webpack_require__(132);
const csvParser = __webpack_require__(48);
const s3_external_1 = __webpack_require__(703);
const transfer_assets_entity_1 = __webpack_require__(54);
const transfer_status_enum_1 = __webpack_require__(634);
const uploaded_file_enum_1 = __webpack_require__(897);
let DashboardFileProcessor = class DashboardFileProcessor {
    constructor(updateFiles, DashboardTransferList, s3External) {
        this.updateFiles = updateFiles;
        this.DashboardTransferList = DashboardTransferList;
        this.s3External = s3External;
    }
    async fileProcessor() {
        const results = await this.updateFiles.find({ where: { status: uploaded_file_enum_1.UploadedFileEnum.UPLOADED } });
        for (const file of results) {
            try {
                console.log(`[FileProcessor] - Processing file: ${file.link}`);
                const fileStream = await this.s3External.downloadFile(file.link);
                const data = await this.parseCsv(fileStream);
                const enrichedData = data.map((item) => ({
                    asset: item.asset,
                    name: item.name,
                    wallet: item.wallet,
                    amount: parseFloat(item.amount),
                    email: item.email,
                    obs: item.obs,
                    status: transfer_status_enum_1.TransferStatusEnum.PENDING,
                    updateFileId: file.id,
                }));
                console.log(`[FileProcessor] - Processed data with IDs:`, enrichedData);
                for (const record of enrichedData) {
                    const exists = await this.DashboardTransferList.findOne({
                        where: {
                            asset: record.asset,
                            name: record.name,
                            wallet: record.wallet,
                            amount: record.amount,
                            email: record.email,
                            obs: record.obs,
                            updateFileId: record.updateFileId,
                        },
                    });
                    if (!exists) {
                        await this.DashboardTransferList.save(record);
                    }
                    else {
                        console.log(`[FileProcessor] - Skipping duplicate record:`, record);
                    }
                }
            }
            catch (error) {
                console.error(`[FileProcessor] - Error processing file: ${file.link}`, error);
            }
        }
    }
    parseCsv(stream) {
        return new Promise((resolve, reject) => {
            const results = [];
            stream
                .pipe(csvParser())
                .on('data', (data) => results.push(data))
                .on('end', () => resolve(results))
                .on('error', (error) => reject(error));
        });
    }
};
exports.DashboardFileProcessor = DashboardFileProcessor;
exports.DashboardFileProcessor = DashboardFileProcessor = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(uploaded_files_entity_1.UploadedFiles)),
    __param(1, (0, typeorm_1.InjectRepository)(transfer_assets_entity_1.DashboardTransferList)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _b : Object, typeof (_c = typeof s3_external_1.S3External !== "undefined" && s3_external_1.S3External) === "function" ? _c : Object])
], DashboardFileProcessor);


/***/ }),

/***/ 43:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-s3");

/***/ }),

/***/ 563:
/***/ ((module) => {

module.exports = require("@nestjs/common");

/***/ }),

/***/ 781:
/***/ ((module) => {

module.exports = require("@nestjs/core");

/***/ }),

/***/ 522:
/***/ ((module) => {

module.exports = require("@nestjs/typeorm");

/***/ }),

/***/ 48:
/***/ ((module) => {

module.exports = require("csv-parser");

/***/ }),

/***/ 818:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 132:
/***/ ((module) => {

module.exports = require("typeorm");

/***/ }),

/***/ 203:
/***/ ((module) => {

module.exports = require("stream");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.handler = void 0;
exports.createInstance = createInstance;
const core_1 = __webpack_require__(781);
const dashboard_file_processor_repository_1 = __webpack_require__(56);
const dashboard_file_processor_module_1 = __webpack_require__(205);
async function createInstance() {
    const server = await core_1.NestFactory.createApplicationContext(dashboard_file_processor_module_1.DashboardFileProcessorModule);
    return server.get(dashboard_file_processor_repository_1.IDashboardFileProcessorRepository);
}
const handler = async () => {
    try {
        const instance = await createInstance();
        console.log('[Handler] - start dashboard file processor.');
        await instance.fileProcessor();
    }
    catch (error) {
        console.error(error);
    }
};
exports.handler = handler;

})();

var __webpack_export_target__ = exports;
for(var __webpack_i__ in __webpack_exports__) __webpack_export_target__[__webpack_i__] = __webpack_exports__[__webpack_i__];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=handler.js.map