/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 777:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BlockchainTransactionStatusEnum = exports.BlockchainTransactionsTypeEnum = exports.BlockchainEnum = void 0;
var BlockchainEnum;
(function (BlockchainEnum) {
    BlockchainEnum["BLOCKCHAIN_API_URL"] = "BLOCKCHAIN_API_URL";
    BlockchainEnum["BLOCKCHAIN_API_KEY_HASH"] = "BLOCKCHAIN_API_KEY_HASH";
    BlockchainEnum["BLOCKCHAIN_TRANSFER_FEE"] = "BLOCKCHAIN_TRANSFER_FEE";
    BlockchainEnum["TRANSFER_STATUS"] = "/transactions/status?id=";
    BlockchainEnum["BROADCAST"] = "/transactions/broadcast";
})(BlockchainEnum || (exports.BlockchainEnum = BlockchainEnum = {}));
var BlockchainTransactionsTypeEnum;
(function (BlockchainTransactionsTypeEnum) {
    BlockchainTransactionsTypeEnum[BlockchainTransactionsTypeEnum["TRANSFER"] = 4] = "TRANSFER";
})(BlockchainTransactionsTypeEnum || (exports.BlockchainTransactionsTypeEnum = BlockchainTransactionsTypeEnum = {}));
var BlockchainTransactionStatusEnum;
(function (BlockchainTransactionStatusEnum) {
    BlockchainTransactionStatusEnum["CONFIRMED"] = "confirmed";
    BlockchainTransactionStatusEnum["UNCONFIRMED"] = "unconfirmed";
    BlockchainTransactionStatusEnum["NOT_FOUND"] = "not_found";
})(BlockchainTransactionStatusEnum || (exports.BlockchainTransactionStatusEnum = BlockchainTransactionStatusEnum = {}));


/***/ }),

/***/ 685:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProfileUserEnum = void 0;
var ProfileUserEnum;
(function (ProfileUserEnum) {
    ProfileUserEnum["USER"] = "USER";
    ProfileUserEnum["ADMIN"] = "ADMIN";
})(ProfileUserEnum || (exports.ProfileUserEnum = ProfileUserEnum = {}));


/***/ }),

/***/ 634:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TransferStatusEnum = void 0;
var TransferStatusEnum;
(function (TransferStatusEnum) {
    TransferStatusEnum["PENDING"] = "PENDING";
    TransferStatusEnum["COMPLETED"] = "COMPLETED";
    TransferStatusEnum["FAILED"] = "FAILED";
})(TransferStatusEnum || (exports.TransferStatusEnum = TransferStatusEnum = {}));


/***/ }),

/***/ 897:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadedFileEnum = void 0;
var UploadedFileEnum;
(function (UploadedFileEnum) {
    UploadedFileEnum["UPLOADED"] = "UPLOADED";
    UploadedFileEnum["PROCESSING"] = "PROCESSING";
    UploadedFileEnum["PROCESSED"] = "PROCESSED";
})(UploadedFileEnum || (exports.UploadedFileEnum = UploadedFileEnum = {}));


/***/ }),

/***/ 782:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BaseEntity = void 0;
const typeorm_1 = __webpack_require__(132);
class BaseEntity {
}
exports.BaseEntity = BaseEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], BaseEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at', type: 'timestamp' }),
    __metadata("design:type", typeof (_a = typeof Date !== "undefined" && Date) === "function" ? _a : Object)
], BaseEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at', type: 'timestamp' }),
    __metadata("design:type", typeof (_b = typeof Date !== "undefined" && Date) === "function" ? _b : Object)
], BaseEntity.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.DeleteDateColumn)({ name: 'deleted_at', type: 'timestamp', nullable: true }),
    __metadata("design:type", typeof (_c = typeof Date !== "undefined" && Date) === "function" ? _c : Object)
], BaseEntity.prototype, "deletedAt", void 0);


/***/ }),

/***/ 54:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DashboardTransferList = void 0;
const typeorm_1 = __webpack_require__(132);
const base_entity_1 = __webpack_require__(782);
const uploaded_files_entity_1 = __webpack_require__(515);
const transfer_status_enum_1 = __webpack_require__(634);
let DashboardTransferList = class DashboardTransferList extends base_entity_1.BaseEntity {
};
exports.DashboardTransferList = DashboardTransferList;
__decorate([
    (0, typeorm_1.ManyToOne)(() => uploaded_files_entity_1.UploadedFiles, (updateFile) => updateFile.id, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'uploaded_file_id' }),
    __metadata("design:type", typeof (_a = typeof uploaded_files_entity_1.UploadedFiles !== "undefined" && uploaded_files_entity_1.UploadedFiles) === "function" ? _a : Object)
], DashboardTransferList.prototype, "updateFile", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_file_id', type: 'uuid' }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "updateFileId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "asset", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "wallet", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2 }),
    __metadata("design:type", Number)
], DashboardTransferList.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "obs", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "enum",
        enum: transfer_status_enum_1.TransferStatusEnum,
        default: transfer_status_enum_1.TransferStatusEnum.PENDING,
    }),
    __metadata("design:type", String)
], DashboardTransferList.prototype, "status", void 0);
exports.DashboardTransferList = DashboardTransferList = __decorate([
    (0, typeorm_1.Entity)('transfer_assets')
], DashboardTransferList);


/***/ }),

/***/ 515:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UploadedFiles = void 0;
const typeorm_1 = __webpack_require__(132);
const base_entity_1 = __webpack_require__(782);
const uploaded_file_enum_1 = __webpack_require__(897);
let UploadedFiles = class UploadedFiles extends base_entity_1.BaseEntity {
};
exports.UploadedFiles = UploadedFiles;
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], UploadedFiles.prototype, "link", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: "enum",
        enum: uploaded_file_enum_1.UploadedFileEnum,
        default: uploaded_file_enum_1.UploadedFileEnum.UPLOADED,
    }),
    __metadata("design:type", String)
], UploadedFiles.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_id' }),
    __metadata("design:type", String)
], UploadedFiles.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], UploadedFiles.prototype, "hash", void 0);
exports.UploadedFiles = UploadedFiles = __decorate([
    (0, typeorm_1.Entity)('uploaded_files')
], UploadedFiles);


/***/ }),

/***/ 845:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UserEntity = void 0;
const typeorm_1 = __webpack_require__(132);
const base_entity_1 = __webpack_require__(782);
const profile_user_enum_1 = __webpack_require__(685);
let UserEntity = class UserEntity extends base_entity_1.BaseEntity {
};
exports.UserEntity = UserEntity;
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], UserEntity.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, unique: true }),
    __metadata("design:type", String)
], UserEntity.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cpf_cnpj', type: 'varchar', length: 20, unique: true, nullable: true }),
    __metadata("design:type", String)
], UserEntity.prototype, "cpfCnpj", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, unique: true, nullable: true }),
    __metadata("design:type", String)
], UserEntity.prototype, "passport", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_bdm_id', type: 'integer', default: 0, unique: true }),
    __metadata("design:type", Number)
], UserEntity.prototype, "userBdmId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_market_id', type: 'uuid', unique: true }),
    __metadata("design:type", String)
], UserEntity.prototype, "userMarketId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: profile_user_enum_1.ProfileUserEnum, default: profile_user_enum_1.ProfileUserEnum.USER }),
    __metadata("design:type", typeof (_a = typeof profile_user_enum_1.ProfileUserEnum !== "undefined" && profile_user_enum_1.ProfileUserEnum) === "function" ? _a : Object)
], UserEntity.prototype, "profile", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_admin', type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], UserEntity.prototype, "isAdmin", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_active', type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], UserEntity.prototype, "isActive", void 0);
exports.UserEntity = UserEntity = __decorate([
    (0, typeorm_1.Entity)('users')
], UserEntity);


/***/ }),

/***/ 518:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IAuthExetrnal = void 0;
exports.IAuthExetrnal = Symbol('IAuthExetrnal');


/***/ }),

/***/ 708:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IBdmExternal = exports.BalanceResponse = void 0;
class BalanceResponse {
}
exports.BalanceResponse = BalanceResponse;
exports.IBdmExternal = Symbol('IBdmExternal');


/***/ }),

/***/ 3:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.IBlockchainExternal = void 0;
exports.IBlockchainExternal = Symbol('IBlockchainExternal');


/***/ }),

/***/ 977:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ICognitoProvider = void 0;
exports.ICognitoProvider = Symbol('ICognitoProvider');


/***/ }),

/***/ 596:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ITransferAssetRepository = void 0;
exports.ITransferAssetRepository = Symbol('ITransferAssetRepository');


/***/ }),

/***/ 67:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ITransferAssetUseCase = void 0;
exports.ITransferAssetUseCase = Symbol('ITransferAssetUseCase');


/***/ }),

/***/ 615:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DashboardTransferAssetsModule = void 0;
const transfer_assets_entity_1 = __webpack_require__(54);
const uploaded_files_entity_1 = __webpack_require__(515);
const database_module_1 = __webpack_require__(207);
const common_1 = __webpack_require__(563);
const typeorm_1 = __webpack_require__(522);
const http_bdm_module_1 = __webpack_require__(513);
const sqs_provider_1 = __webpack_require__(491);
const transfer_repository_1 = __webpack_require__(468);
const transfer_repository_2 = __webpack_require__(596);
const transfer_asset_use_case_1 = __webpack_require__(92);
const bdm_external_1 = __webpack_require__(964);
const cognito_module_1 = __webpack_require__(638);
const cognito_provider_1 = __webpack_require__(977);
const cognito_provider_2 = __webpack_require__(979);
const common_2 = __webpack_require__(563);
const blockchain_external_1 = __webpack_require__(443);
const user_entity_1 = __webpack_require__(845);
const blockchain_external_2 = __webpack_require__(3);
const bdm_external_2 = __webpack_require__(708);
const transfer_asset_user_case_1 = __webpack_require__(67);
const http_blockchain_module_1 = __webpack_require__(66);
const config_1 = __webpack_require__(428);
const app_config_1 = __webpack_require__(308);
let DashboardTransferAssetsModule = class DashboardTransferAssetsModule {
};
exports.DashboardTransferAssetsModule = DashboardTransferAssetsModule;
exports.DashboardTransferAssetsModule = DashboardTransferAssetsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true, load: [app_config_1.default] }),
            database_module_1.DataBaseModule,
            typeorm_1.TypeOrmModule.forFeature([uploaded_files_entity_1.UploadedFiles, transfer_assets_entity_1.DashboardTransferList, user_entity_1.UserEntity]),
            http_bdm_module_1.HttpBdmModule,
            cognito_module_1.CognitoModule,
            http_blockchain_module_1.HttpBlochChainModule,
        ],
        controllers: [],
        providers: [
            sqs_provider_1.SqsProvider,
            common_2.Logger,
            {
                provide: cognito_provider_1.ICognitoProvider,
                useClass: cognito_provider_2.CognitoProvider,
            },
            {
                provide: transfer_repository_2.ITransferAssetRepository,
                useClass: transfer_repository_1.TransferRepository,
            },
            {
                provide: transfer_asset_user_case_1.ITransferAssetUseCase,
                useClass: transfer_asset_use_case_1.TransferAssetUseCase,
            },
            {
                provide: blockchain_external_2.IBlockchainExternal,
                useClass: blockchain_external_1.BlockchainExternal,
            },
            {
                provide: bdm_external_2.IBdmExternal,
                useClass: bdm_external_1.BdmExternal,
            },
        ],
    })
], DashboardTransferAssetsModule);


/***/ }),

/***/ 92:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TransferAssetUseCase = void 0;
const transfer_repository_1 = __webpack_require__(596);
const common_1 = __webpack_require__(563);
let TransferAssetUseCase = class TransferAssetUseCase {
    constructor(transferRepository) {
        this.transferRepository = transferRepository;
    }
    async execute(body) {
        return await this.transferRepository.processTransfer(body);
    }
};
exports.TransferAssetUseCase = TransferAssetUseCase;
exports.TransferAssetUseCase = TransferAssetUseCase = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(transfer_repository_1.ITransferAssetRepository)),
    __metadata("design:paramtypes", [typeof (_a = typeof transfer_repository_1.ITransferAssetRepository !== "undefined" && transfer_repository_1.ITransferAssetRepository) === "function" ? _a : Object])
], TransferAssetUseCase);


/***/ }),

/***/ 308:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const dotenv = __webpack_require__(818);
dotenv.config();
const AppEnvs = () => ({
    isDevelopment: process.env.ENVIRONMENT === 'production',
    application: {
        serviceName: 'dourado-dashboard-backend',
        port: process.env.HTTP_PORT,
    },
    database: {
        dashboard: {
            type: process.env.DATABASE_TYPE,
            host: process.env.DATABASE_HOST,
            username: process.env.DATABASE_USERNAME,
            password: process.env.DATABASE_PASSWORD,
            database: process.env.DATABASE_NAME,
            port: +process.env.DATABASE_PORT,
            logging: false,
            synchronize: true,
            entities: [`${__dirname}/../**/*.entity.{js,ts}`],
        },
    },
    auth: {
        tokenJwt: {
            secret: process.env.TOKEN_JWT_SECRET,
            signOptions: {
                expiresIn: `${process.env.TOKEN_JWT_EXPIRES}s`,
            },
        },
    },
    bdm: {
        version: process.env.BDM_VERSION,
        url: process.env.BASE_URL_BDM,
        username: process.env.BDM_AUTH_USERNAME,
        password: process.env.BDM_AUTH_PASSWORD,
    },
    transfer: {
        asset: {
            bucketName: process.env.AWS_S3_BUCKET_NAME,
        }
    }
});
exports["default"] = AppEnvs;


/***/ }),

/***/ 451:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dataSourceMigrations = exports.dataSourceDashBoard = void 0;
const dotenv = __webpack_require__(818);
const typeorm_1 = __webpack_require__(132);
dotenv.config();
exports.dataSourceDashBoard = {
    type: process.env.DATABASE_TYPE,
    host: process.env.DATABASE_HOST,
    port: process.env.DATABASE_PORT,
    username: process.env.DATABASE_USERNAME,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
    ssl: false,
    entities: ['dist/domain/entities/**/*.entity{.ts,.js}'],
    synchronize: false,
};
const datasourceMigrations = async () => {
    return new typeorm_1.DataSource({
        ...exports.dataSourceDashBoard,
        ssl: false,
        migrations: ['dist/infrastructure/database/migrations/*.{js,ts}'],
        entities: ['src/domain/entities/**/*.entity{.ts,.js}'],
        synchronize: false,
    });
};
exports.dataSourceMigrations = datasourceMigrations();


/***/ }),

/***/ 207:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DataBaseModule = void 0;
const common_1 = __webpack_require__(563);
const typeorm_1 = __webpack_require__(522);
const postgres_provider_1 = __webpack_require__(451);
let DataBaseModule = class DataBaseModule {
};
exports.DataBaseModule = DataBaseModule;
exports.DataBaseModule = DataBaseModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forRootAsync({
                useFactory: () => Object.assign(postgres_provider_1.dataSourceDashBoard, { autoLoadEntities: true }),
            }),
        ],
        exports: [],
    })
], DataBaseModule);


/***/ }),

/***/ 699:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuthExternal_1;
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthExternal = void 0;
const common_1 = __webpack_require__(563);
const http_bdm_provider_1 = __webpack_require__(908);
let AuthExternal = AuthExternal_1 = class AuthExternal {
    constructor(httpClient, logger) {
        this.httpClient = httpClient;
        this.logger = logger;
        this.logger = new common_1.Logger(AuthExternal_1.name);
    }
    async signIn(data) {
        this.logger.log('Exemplo de uso de api externa');
        return await this.httpClient.fetchData({
            url: '/bdm',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' },
            data,
        });
    }
};
exports.AuthExternal = AuthExternal;
exports.AuthExternal = AuthExternal = AuthExternal_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof http_bdm_provider_1.HttpBdmProvider !== "undefined" && http_bdm_provider_1.HttpBdmProvider) === "function" ? _a : Object, typeof (_b = typeof common_1.Logger !== "undefined" && common_1.Logger) === "function" ? _b : Object])
], AuthExternal);


/***/ }),

/***/ 964:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BdmExternal_1;
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BdmExternal = void 0;
const cognito_provider_1 = __webpack_require__(977);
const common_1 = __webpack_require__(563);
const config_1 = __webpack_require__(428);
const http_bdm_provider_1 = __webpack_require__(908);
let BdmExternal = BdmExternal_1 = class BdmExternal {
    constructor(cognito, httpBdmClient, logger, configService) {
        this.cognito = cognito;
        this.httpBdmClient = httpBdmClient;
        this.logger = logger;
        this.configService = configService;
        this.logger = new common_1.Logger(BdmExternal_1.name);
        this.BDM_API_KEY = this.configService.getOrThrow('BDM_API_KEY');
    }
    async findDefaultWalletByUserId(userId) {
        this.logger.log('Buscando wallet BDM');
        try {
            this.tokenJwt = await this.cognito.signInBdm();
            const response = await this.httpBdmClient.fetchData({
                url: `/wallets`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'bdm-api-key': this.BDM_API_KEY,
                    Authorization: `Bearer ${this.tokenJwt}`,
                    payload: `custom:id:${userId}]`,
                },
            });
            if (Array.isArray(response)) {
                const defaultWallet = response.find(wallet => wallet.isDefault === true);
                if (defaultWallet) {
                    return defaultWallet;
                }
                return response[0];
            }
            return response;
        }
        catch (error) {
            this.logger.error(`Erro ao buscar wallet do BDM`);
            this.logger.error(error.message);
            throw error;
        }
    }
    async getCurrencies() {
        this.logger.log('Buscando currencies BDM');
        try {
            this.tokenJwt = await this.cognito.signInBdm();
            const response = await this.httpBdmClient.fetchData({
                url: `/currencies`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${this.tokenJwt}`,
                },
            });
            return response;
        }
        catch (error) {
            this.logger.error(`Erro ao buscar currencies do BDM`);
            this.logger.error(error.message);
            throw error;
        }
    }
    async getBdmUserData(userId) {
        this.logger.log('Buscando dados do usuário BDM');
        try {
            this.tokenJwt = await this.cognito.signInBdm();
            const response = await this.httpBdmClient.fetchData({
                url: `/users/info`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${this.tokenJwt}`,
                    payload: `custom:id:${userId}]`,
                },
            });
            return response;
        }
        catch (error) {
            this.logger.error(`Erro ao buscar currencies do BDM`);
            this.logger.error(error.message);
            throw error;
        }
    }
    async getBdmUserDataByEmail(email) {
        const attachment = `${email}:`;
        common_1.Logger.log(`${attachment}Buscando dados do usuário BDM pelo email`, 'getBdmUserDataByEmail');
        try {
            const cognitoResponse = await this.cognito.signInBdmFullResponse();
            const response = await this.httpBdmClient.fetchData({
                url: `/users/by-email/${email}`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${cognitoResponse.AccessToken}`,
                    payload: `custom:id:${cognitoResponse['custom:id']}]`,
                },
            });
            return response;
        }
        catch (error) {
            common_1.Logger.error(attachment + error.message, error.stack, 'getBdmUserDataByEmail');
            error.message = 'Erro ao buscar dados do usuário BDM pelo email:' + error.message;
            throw error;
        }
    }
    async getBdmUserDataByWalletId(walletId) {
        const attachment = `${walletId}:`;
        common_1.Logger.log(`${attachment}Buscando dados do usuário BDM pelo walletId`, 'getBdmUserDataByWalletId');
        try {
            const cognitoResponse = await this.cognito.signInBdmFullResponse();
            const response = await this.httpBdmClient.fetchData({
                url: `/users/by-wallet/${walletId}`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${cognitoResponse.AccessToken}`,
                    payload: `custom:id:${cognitoResponse['custom:id']}]`,
                },
            });
            return response;
        }
        catch (error) {
            common_1.Logger.error(attachment + error.response, error.stack, 'getBdmUserDataByWalletId');
            error.message = 'Erro ao buscar dados do usuário BDM pelo identificador da carteira - ' + error.message;
            throw error;
        }
    }
    async getDefaultWalletByEmail(email) {
        const attachment = `${email}:`;
        common_1.Logger.log(`${attachment}Buscando dados do usuário BDM pelo email`, 'getBdmUserDataByEmail');
        try {
            const cognitoResponse = await this.cognito.signInBdmFullResponse();
            const response = await this.httpBdmClient.fetchData({
                url: `/Users/default-wallet/${email}`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${cognitoResponse.AccessToken}`,
                    payload: `custom:id:${cognitoResponse['custom:id']}]`,
                },
            });
            return response;
        }
        catch (error) {
            common_1.Logger.error(attachment + error.message, error.stack, 'getBdbDefaultWalletByEmail');
            error.message = 'Erro ao buscar a carteira padrão do usuario:' + error.message;
            throw error;
        }
    }
    async findWalletById(walletId) {
        this.logger.log('Buscando wallet BDM');
        try {
            const cognitoResponse = await this.cognito.signInBdmFullResponse();
            this.logger.debug(`Token JWT obtained: ${cognitoResponse.AccessToken.substring(0, 20)}...`);
            const response = await this.httpBdmClient.fetchData({
                url: `/wallets/pos/${walletId}`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'bdm-api-key': this.BDM_API_KEY,
                    Authorization: `Bearer ${cognitoResponse.AccessToken}`,
                    payload: `custom:id:${cognitoResponse['custom:id']}]`,
                },
            });
            return response;
        }
        catch (error) {
            this.logger.error(`Erro ao buscar wallet do BDM`);
            this.logger.error(error.message);
            throw error;
        }
    }
    async transferAsset(body) {
        this.logger.log('Transferindo assets no BDM');
        try {
            const cognitoResponse = await this.cognito.signInBdmFullResponse();
            this.logger.debug(`Token JWT obtained: ${cognitoResponse.AccessToken.substring(0, 20)}...`);
            this.logger.debug(`Request body: ${JSON.stringify(body)}`);
            const response = await this.httpBdmClient.fetchData({
                url: `operations/BDM/transfer`,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'bdm-api-key': this.BDM_API_KEY,
                    Authorization: `Bearer ${cognitoResponse.AccessToken}`,
                    payload: `custom:id:${cognitoResponse['custom:id']}]`,
                },
                data: body
            });
            return response;
        }
        catch (error) {
            this.logger.error(`Erro ao transferir assets: ${error.message}`);
            this.logger.error(error.stack);
            throw error;
        }
    }
};
exports.BdmExternal = BdmExternal;
exports.BdmExternal = BdmExternal = BdmExternal_1 = __decorate([
    __param(0, (0, common_1.Inject)(cognito_provider_1.ICognitoProvider)),
    __metadata("design:paramtypes", [typeof (_a = typeof cognito_provider_1.ICognitoProvider !== "undefined" && cognito_provider_1.ICognitoProvider) === "function" ? _a : Object, typeof (_b = typeof http_bdm_provider_1.HttpBdmProvider !== "undefined" && http_bdm_provider_1.HttpBdmProvider) === "function" ? _b : Object, typeof (_c = typeof common_1.Logger !== "undefined" && common_1.Logger) === "function" ? _c : Object, typeof (_d = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _d : Object])
], BdmExternal);


/***/ }),

/***/ 443:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.BlockchainExternal = void 0;
const common_1 = __webpack_require__(563);
const blockchain_enum_1 = __webpack_require__(777);
const crypto_util_1 = __webpack_require__(966);
const ts_lib_crypto_1 = __webpack_require__(18);
const http_blockchain_provider_1 = __webpack_require__(928);
let BlockchainExternal = class BlockchainExternal {
    constructor(httpClient, logger) {
        this.httpClient = httpClient;
        this.logger = logger;
        this.FEE = 1;
    }
    async sendTransfer(data, keyPair) {
        const now = new Date();
        const broadcastPayload = this.createAssetTransferTransaction({
            ...data,
            attachment: data.attachment ?? '',
            timestamp: now.getTime(),
            fee: this.FEE,
        }, keyPair);
        this.logger.debug(`broadcastPayload ${JSON.stringify(broadcastPayload)}`);
        const broadcastResponse = await this.broadcast(broadcastPayload);
        return {
            id: broadcastResponse.id,
        };
    }
    async broadcast(transaction) {
        const response = await this.httpClient.request({
            url: `${blockchain_enum_1.BlockchainEnum.BROADCAST}`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            data: transaction,
        });
        return response;
    }
    createAssetTransferTransaction(data, keyPair) {
        data.attachment = (0, crypto_util_1.stringToByteArray)(data.attachment ?? '');
        const signaturePayload = this.prepareDataForSignature(data, keyPair.publicKey);
        const signature = (0, crypto_util_1.getSignature)(signaturePayload, keyPair);
        const broadCastPayload = {
            id: (0, crypto_util_1.buildId)(signaturePayload),
            signature,
            amount: data.amount,
            type: blockchain_enum_1.BlockchainTransactionsTypeEnum.TRANSFER,
            fee: data.fee,
            feeAssetId: data.feeAssetId,
            recipient: data.recipient,
            senderPublicKey: keyPair.publicKey,
            timestamp: data.timestamp,
            assetId: data.assetId,
            attachment: (0, ts_lib_crypto_1.base58Encode)(data.attachment),
        };
        return broadCastPayload;
    }
    prepareDataForSignature(data, senderPublicKey) {
        return [].concat((0, crypto_util_1.getAssetTransferTxTypeBytes)(), (0, crypto_util_1.getPublicKeyBytes)(senderPublicKey), (0, crypto_util_1.getAssetIdBytes)(data.assetId), (0, crypto_util_1.getFeeAssetIdBytes)(data.feeAssetId), (0, crypto_util_1.getTimestampBytes)(data.timestamp), (0, crypto_util_1.getAmountBytes)(data.amount), (0, crypto_util_1.getFeeBytes)(data.fee), (0, crypto_util_1.getRecipientBytes)(data.recipient), (0, crypto_util_1.getAttachmentBytes)(data.attachment));
    }
    async checkStatusPayment(data) {
        const result = await this.httpClient.request({
            url: `${blockchain_enum_1.BlockchainEnum.TRANSFER_STATUS}${data.blockchain_code}`,
            method: 'GET',
            data,
        });
        return result;
    }
    async getBDMBalance(address) {
        try {
            if (!this.httpClient) {
                this.logger.error('httpClient is undefined in BlockchainExternal');
                throw new Error('HTTP client not available');
            }
            this.logger.log(`Calling getBDMBalance for address: ${address}`);
            const response = await this.httpClient.request({
                url: `/addresses/effectiveBalance/${address}`,
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            return response;
        }
        catch (error) {
            this.logger.error(`Error in getBDMBalance: ${error.message}`, error.stack);
            throw error;
        }
    }
};
exports.BlockchainExternal = BlockchainExternal;
exports.BlockchainExternal = BlockchainExternal = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof http_blockchain_provider_1.HttpBlockchainProvider !== "undefined" && http_blockchain_provider_1.HttpBlockchainProvider) === "function" ? _a : Object, typeof (_b = typeof common_1.Logger !== "undefined" && common_1.Logger) === "function" ? _b : Object])
], BlockchainExternal);


/***/ }),

/***/ 638:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CognitoModule = void 0;
const cognito_provider_1 = __webpack_require__(977);
const common_1 = __webpack_require__(563);
const config_1 = __webpack_require__(428);
const cognito_provider_2 = __webpack_require__(979);
let CognitoModule = class CognitoModule {
};
exports.CognitoModule = CognitoModule;
exports.CognitoModule = CognitoModule = __decorate([
    (0, common_1.Module)({
        imports: [config_1.ConfigModule.forRoot({ isGlobal: true })],
        providers: [
            common_1.Logger,
            {
                provide: cognito_provider_1.ICognitoProvider,
                useClass: cognito_provider_2.CognitoProvider,
            },
        ],
        exports: [cognito_provider_1.ICognitoProvider],
    })
], CognitoModule);


/***/ }),

/***/ 979:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CognitoProvider_1;
var _a;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CognitoProvider = void 0;
const client_cognito_identity_provider_1 = __webpack_require__(993);
const common_1 = __webpack_require__(563);
const crypto = __webpack_require__(982);
const jwt = __webpack_require__(829);
let CognitoProvider = CognitoProvider_1 = class CognitoProvider {
    constructor(logger) {
        this.logger = logger;
        this.cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
            region: process.env.AWS_REGION,
            credentials: {
                accessKeyId: process.env.AWS_ACCESS_KEY_ID,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
            },
        });
        this.clientId = process.env.AWS_COGNITO_CLIENT_ID;
        this.clientSecret = process.env.AWS_COGNITO_CLIENT_ID_SECRET;
        this.bdmUserName = process.env.BDM_AUTH_USERNAME;
        this.bdmPassword = process.env.BDM_AUTH_PASSWORD;
        this.logger = new common_1.Logger(CognitoProvider_1.name);
    }
    async signIn(data) {
        const secretHash = await this.calculateSecretHash(data.username);
        const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
            AuthFlow: client_cognito_identity_provider_1.AuthFlowType.USER_PASSWORD_AUTH,
            AuthParameters: {
                USERNAME: data.username,
                PASSWORD: data.password,
                SECRET_HASH: secretHash,
            },
            ClientId: process.env.AWS_COGNITO_CLIENT_ID,
        });
        return await this.cognito.send(command);
    }
    async calculateSecretHash(username) {
        const hmac = crypto.createHmac('sha256', this.clientSecret);
        hmac.update(`${username}${this.clientId}`);
        return hmac.digest('base64');
    }
    async signInBdm() {
        try {
            const result = await this.signIn({
                username: this.bdmUserName,
                password: this.bdmPassword,
            });
            return result.AuthenticationResult.AccessToken;
        }
        catch (error) {
            this.logger.log(error);
            return '';
        }
    }
    async signInBdmFullResponse() {
        try {
            common_1.Logger.log('Sign in BDM Cognito', 'signInBdmFullResponse');
            const cognitoResponse = await this.signIn({
                username: this.bdmUserName,
                password: this.bdmPassword,
            });
            const idTokenInfo = jwt.decode(cognitoResponse.AuthenticationResult.IdToken);
            common_1.Logger.debug(`idTokenInfo \n${JSON.stringify(idTokenInfo)}`, 'signInBdmFullResponse');
            return {
                ...idTokenInfo,
                AccessToken: cognitoResponse.AuthenticationResult.AccessToken,
            };
        }
        catch (error) {
            common_1.Logger.error(error, error.stack, 'signInBdmFullResponse');
            throw error;
        }
    }
};
exports.CognitoProvider = CognitoProvider;
exports.CognitoProvider = CognitoProvider = CognitoProvider_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof common_1.Logger !== "undefined" && common_1.Logger) === "function" ? _a : Object])
], CognitoProvider);


/***/ }),

/***/ 491:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.SqsProvider = void 0;
const client_sqs_1 = __webpack_require__(330);
const common_1 = __webpack_require__(563);
const uuid_1 = __webpack_require__(903);
let SqsProvider = class SqsProvider {
    constructor() {
        if (process.env.IS_OFFLINE === 'true') {
            this.awsConfig = {
                endpoint: process.env.AWS_SQS_ENDPOINT,
                region: process.env.AWS_REGION,
                apiVersion: process.env.AWS_SQS_API_VERSION,
                credentials: {
                    accessKeyId: String(process.env.AWS_ACCESS_KEY_ID),
                    secretAccessKey: String(process.env.AWS_SECRET_ACCESS_KEY),
                    sessionToken: process.env.AWS_SESSION_TOKEN,
                },
                logger: undefined,
            };
        }
        this.messageGroupId = 'DefaultGroup';
        this.sqsClient = new client_sqs_1.SQSClient(this.awsConfig);
    }
    formatMessageBeforeSend(message = {}) {
        switch (typeof message) {
            case 'string':
                return message;
            case 'object':
                if (!message) {
                    return '';
                }
                else {
                    return JSON.stringify(message) || message?.toString();
                }
            default:
                return message.toString();
        }
    }
    msgParams(queueUrl, message) {
        const isFifoQueue = queueUrl?.includes('.fifo');
        const messageBody = this.formatMessageBeforeSend(message);
        return {
            QueueUrl: queueUrl,
            MessageBody: messageBody,
            MessageDeduplicationId: isFifoQueue ? (0, uuid_1.v4)() : undefined,
            MessageGroupId: isFifoQueue ? this.messageGroupId : undefined,
        };
    }
    receiveParam(queueUrl) {
        return {
            QueueUrl: queueUrl,
            MaxNumberOfMessages: 10,
            VisibilityTimeout: 300,
            WaitTimeSeconds: 10,
            MessageAttributeNames: ['All'],
        };
    }
    async sendMessage(queueUrl, message) {
        let messageId = '';
        try {
            const messageMaked = this.msgParams(queueUrl, message);
            const response = await this.sqsClient.send(new client_sqs_1.SendMessageCommand(messageMaked));
            if (response?.MessageId) {
                messageId = response.MessageId;
            }
            return messageId;
        }
        catch (error) {
            throw error;
        }
    }
    async getMessages(queueUrl) {
        const messages = [];
        try {
            const result = await this.sqsClient.send(new client_sqs_1.ReceiveMessageCommand(this.receiveParam(queueUrl)));
            if (result?.Messages) {
                for (const message of result.Messages) {
                    messages.push(message);
                    this.deleteMessage(queueUrl, message);
                }
            }
        }
        catch (error) {
            throw error;
        }
        return messages;
    }
    async deleteMessage(queueUrl, message) {
        let isDeleted = false;
        try {
            const result = await this.sqsClient.send(new client_sqs_1.DeleteMessageCommand({
                QueueUrl: queueUrl,
                ReceiptHandle: `${message.ReceiptHandle}`,
            }));
            if (result.$metadata?.httpStatusCode &&
                String(result.$metadata?.httpStatusCode)[2] === '2') {
                isDeleted = true;
            }
        }
        catch (error) {
            throw error;
        }
        return isDeleted;
    }
};
exports.SqsProvider = SqsProvider;
exports.SqsProvider = SqsProvider = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], SqsProvider);


/***/ }),

/***/ 513:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HttpBdmModule = void 0;
const auth_external_1 = __webpack_require__(518);
const cognito_provider_1 = __webpack_require__(977);
const auth_external_2 = __webpack_require__(699);
const common_1 = __webpack_require__(563);
const config_1 = __webpack_require__(428);
const http_bdm_provider_1 = __webpack_require__(908);
const cognito_provider_2 = __webpack_require__(979);
let HttpBdmModule = class HttpBdmModule {
};
exports.HttpBdmModule = HttpBdmModule;
exports.HttpBdmModule = HttpBdmModule = __decorate([
    (0, common_1.Module)({
        imports: [config_1.ConfigModule.forRoot({ isGlobal: true })],
        providers: [
            common_1.Logger,
            http_bdm_provider_1.HttpBdmProvider,
            {
                provide: auth_external_1.IAuthExetrnal,
                useClass: auth_external_2.AuthExternal,
            },
            {
                provide: cognito_provider_1.ICognitoProvider,
                useClass: cognito_provider_2.CognitoProvider,
            },
        ],
        exports: [http_bdm_provider_1.HttpBdmProvider, auth_external_1.IAuthExetrnal],
    })
], HttpBdmModule);


/***/ }),

/***/ 908:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var HttpBdmProvider_1;
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HttpBdmProvider = void 0;
const cognito_provider_1 = __webpack_require__(977);
const common_1 = __webpack_require__(563);
const config_1 = __webpack_require__(428);
const axios_1 = __webpack_require__(938);
let HttpBdmProvider = HttpBdmProvider_1 = class HttpBdmProvider {
    constructor(cognitoProvider, logger, configService) {
        this.cognitoProvider = cognitoProvider;
        this.logger = logger;
        this.configService = configService;
        this.logger = new common_1.Logger(HttpBdmProvider_1.name);
        this.username = this.configService.get('bdm.username');
        this.password = this.configService.get('bdm.password');
        this.httpClient = axios_1.default.create({
            baseURL: `${this.configService.get('bdm.url')}/${this.configService.get('bdm.version')}`,
            timeout: +process.env.HTTP_TIMEOUT | 30000,
        });
        this.httpClient.interceptors.request.use(function (config) {
            config['metadata'] = { ...config['metadata'], startDate: new Date() };
            return config;
        });
        this.httpClient.interceptors.response.use((response) => {
            const { config } = response;
            config['metadata'] = { ...config['metadata'], endDate: new Date() };
            const duration = config['metadata'].endDate.getTime() - config['metadata'].startDate.getTime();
            this.logger.log(`${config.method.toUpperCase()} ${config.url} ${duration}ms`);
            return response;
        }, (err) => {
            this.logger.error(err);
            return Promise.reject(err);
        });
    }
    async fetchData(config) {
        try {
            await this.authenticate();
            const response = await this.httpClient.request(config);
            return response.data;
        }
        catch (error) {
            if (axios_1.default.isAxiosError(error)) {
                const err = error;
                if (err.response) {
                    this.logger.log(`Erro HTTP: ${err.response.status} - ${err.response.statusText} - ${JSON.stringify(err.response.data)}`);
                    throw new common_1.HttpException(undefined, err.response.status);
                }
                this.logger.error('Erro no processo principal.');
            }
            this.logger.error('Erro ao buscar dados.');
            throw new common_1.InternalServerErrorException();
        }
    }
    async authenticate() {
        try {
            const token = await this.getAuthToken();
            this.httpClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        }
        catch (error) {
            this.logger.error('Erro ao autenticar.', error);
            throw new common_1.InternalServerErrorException('Falha na autenticação com a bdm.');
        }
    }
    async getAuthToken() {
        const { AuthenticationResult } = await this.cognitoProvider.signIn({
            username: this.username,
            password: this.password,
        });
        return AuthenticationResult.AccessToken;
    }
};
exports.HttpBdmProvider = HttpBdmProvider;
exports.HttpBdmProvider = HttpBdmProvider = HttpBdmProvider_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(cognito_provider_1.ICognitoProvider)),
    __metadata("design:paramtypes", [typeof (_a = typeof cognito_provider_1.ICognitoProvider !== "undefined" && cognito_provider_1.ICognitoProvider) === "function" ? _a : Object, typeof (_b = typeof common_1.Logger !== "undefined" && common_1.Logger) === "function" ? _b : Object, typeof (_c = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _c : Object])
], HttpBdmProvider);


/***/ }),

/***/ 66:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HttpBlochChainModule = void 0;
const common_1 = __webpack_require__(563);
const config_1 = __webpack_require__(428);
const http_blockchain_provider_1 = __webpack_require__(928);
let HttpBlochChainModule = class HttpBlochChainModule {
};
exports.HttpBlochChainModule = HttpBlochChainModule;
exports.HttpBlochChainModule = HttpBlochChainModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true })
        ],
        providers: [
            common_1.Logger,
            http_blockchain_provider_1.HttpBlockchainProvider
        ],
        exports: [http_blockchain_provider_1.HttpBlockchainProvider],
    })
], HttpBlochChainModule);


/***/ }),

/***/ 928:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var HttpBlockchainProvider_1;
var _a, _b;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.HttpBlockchainProvider = void 0;
const blockchain_enum_1 = __webpack_require__(777);
const common_1 = __webpack_require__(563);
const config_1 = __webpack_require__(428);
const axios_1 = __webpack_require__(938);
let HttpBlockchainProvider = HttpBlockchainProvider_1 = class HttpBlockchainProvider {
    constructor(logger, configService) {
        this.logger = logger;
        this.configService = configService;
        this.BLOCKCHAIN_API_URL = '';
        this.BLOCKCHAIN_API_KEY_HASH = '';
        this.BLOCKCHAIN_API_URL =
            this.configService.get(blockchain_enum_1.BlockchainEnum.BLOCKCHAIN_API_URL) ?? '';
        this.BLOCKCHAIN_API_KEY_HASH =
            this.configService.get(blockchain_enum_1.BlockchainEnum.BLOCKCHAIN_API_KEY_HASH) ?? '';
        if (!this.BLOCKCHAIN_API_URL || !this.BLOCKCHAIN_API_KEY_HASH) {
            const errorMessage = `Required environment parameters to work -> [BLOCKCHAIN_API_URL, BLOCKCHAIN_API_KEY_HASH]`;
            this.logger.error(errorMessage);
            throw new Error(errorMessage);
        }
        this.logger = new common_1.Logger(HttpBlockchainProvider_1.name);
        this.httpClient = axios_1.default.create({
            baseURL: `${this.BLOCKCHAIN_API_URL}`,
            timeout: +process.env.HTTP_TIMEOUT || 30000,
            headers: {
                'X-API-Key': this.BLOCKCHAIN_API_KEY_HASH,
            },
        });
        this.httpClient.interceptors.request.use(function (config) {
            config['metadata'] = { ...config['metadata'], startDate: new Date() };
            return config;
        });
        this.httpClient.interceptors.response.use((response) => {
            const { config } = response;
            config['metadata'] = { ...config['metadata'], endDate: new Date() };
            const duration = config['metadata'].endDate.getTime() - config['metadata'].startDate.getTime();
            this.logger.log(`${config.method.toUpperCase()} ${config.url} ${duration}ms`);
            return response;
        }, (err) => {
            this.logger.error(err);
            return Promise.reject(err);
        });
    }
    async request(config) {
        try {
            const response = await this.httpClient.request(config);
            return response.data;
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.InternalServerErrorException(error.message);
        }
    }
};
exports.HttpBlockchainProvider = HttpBlockchainProvider;
exports.HttpBlockchainProvider = HttpBlockchainProvider = HttpBlockchainProvider_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof common_1.Logger !== "undefined" && common_1.Logger) === "function" ? _a : Object, typeof (_b = typeof config_1.ConfigService !== "undefined" && config_1.ConfigService) === "function" ? _b : Object])
], HttpBlockchainProvider);


/***/ }),

/***/ 468:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TransferRepository = void 0;
const transfer_assets_entity_1 = __webpack_require__(54);
const common_1 = __webpack_require__(563);
const typeorm_1 = __webpack_require__(522);
const typeorm_2 = __webpack_require__(132);
const sqs_provider_1 = __webpack_require__(491);
const bdm_external_1 = __webpack_require__(708);
const blockchain_external_1 = __webpack_require__(3);
const transfer_status_enum_1 = __webpack_require__(634);
let TransferRepository = class TransferRepository {
    constructor(dashboardTransferList, sqsProvider, bdmExternal, blockchainExternal) {
        this.dashboardTransferList = dashboardTransferList;
        this.sqsProvider = sqsProvider;
        this.bdmExternal = bdmExternal;
        this.blockchainExternal = blockchainExternal;
        this.awsSqsUrl = process.env.AWS_SQS_TRANSFER_URL;
    }
    async getListAvailableTransfers(email, status) {
        try {
            const response = await this.dashboardTransferList.find({
                where: { email, status },
            });
            return response;
        }
        catch (error) {
            console.error("Error in getListAvailableTransfers method:", error);
            throw error;
        }
    }
    async transfer(ids, user) {
        try {
            let notFoundIds;
            const userReciptData = await this.dashboardTransferList.findBy({ id: (0, typeorm_2.In)(ids) });
            const foundIds = userReciptData.map(item => item.id);
            if (foundIds.length > 0) {
                notFoundIds = ids.filter(id => !foundIds.includes(id.toString()));
                const objectToQueue = userReciptData.map(item => ({
                    transferId: item.id,
                    asset: item.asset,
                    recipetName: item.name,
                    recipetWallet: item.wallet,
                    recipetId: item.wallet,
                    recipetEmail: item.email,
                    amount: item.amount,
                    senderEmail: user.senderEmail,
                    senderDefaultWalletAddress: user.senderWalletAddress,
                    senderWalletId: user.senderWalletId,
                }));
                this.sqsProvider.sendMessage(this.awsSqsUrl, objectToQueue);
                ;
            }
            else {
                return { status: 404, message: 'Nenhum id encontrado' };
            }
            return { status: 200, notFoundIds };
        }
        catch (error) {
            console.error("Error in transfer method:", error);
            throw error;
        }
    }
    async processTransfer(message) {
        try {
            const body = JSON.parse(message.Records[0].body);
            const totalAssetAmount = body.reduce((sum, item) => sum + Number(item.amount), 0);
            const result = await this.blockchainExternal.getBDMBalance(body[0].senderDefaultWalletAddress);
            if (result.balance < totalAssetAmount) {
                return { status: 400, message: 'Saldo insuficiente' };
            }
            for (const item of body) {
                const recipetBdmUserDatabyWalletId = await this.bdmExternal.getBdmUserDataByEmail(item.recipetEmail);
                const recipetWalletData = await this.bdmExternal.findDefaultWalletByUserId(recipetBdmUserDatabyWalletId.id);
                const transferPayload = {
                    wallet_id: item.senderWalletId,
                    destination_user_id: Number(item.recipetWallet),
                    destination_wallet_id: recipetWalletData.id,
                    amount: Number(item.amount),
                    destination_company_id: 1,
                    company_id: 1,
                    asset: item.asset
                };
                try {
                    await this.bdmExternal.transferAsset(transferPayload);
                    await this.dashboardTransferList.update({ id: item.transferId }, { status: transfer_status_enum_1.TransferStatusEnum.COMPLETED });
                }
                catch (err) {
                    await this.dashboardTransferList.update({ id: item.transferId }, { status: transfer_status_enum_1.TransferStatusEnum.FAILED });
                    return { status: 400, message: 'Erro ao transferir ativos' };
                }
            }
            const deleteMessage = {
                ReceiptHandle: message.Records[0].receiptHandle,
                MessageId: message.Records[0].messageId
            };
            await this.sqsProvider.deleteMessage(this.awsSqsUrl, deleteMessage);
            return { status: 200, message: 'Mensagens processadas com sucesso' };
        }
        catch (error) {
            console.error("Error in processTransfer method:", error);
            throw error;
        }
    }
};
exports.TransferRepository = TransferRepository;
exports.TransferRepository = TransferRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(transfer_assets_entity_1.DashboardTransferList)),
    __param(2, (0, common_1.Inject)(bdm_external_1.IBdmExternal)),
    __param(3, (0, common_1.Inject)(blockchain_external_1.IBlockchainExternal)),
    __metadata("design:paramtypes", [typeof (_a = typeof typeorm_2.Repository !== "undefined" && typeorm_2.Repository) === "function" ? _a : Object, typeof (_b = typeof sqs_provider_1.SqsProvider !== "undefined" && sqs_provider_1.SqsProvider) === "function" ? _b : Object, typeof (_c = typeof bdm_external_1.IBdmExternal !== "undefined" && bdm_external_1.IBdmExternal) === "function" ? _c : Object, typeof (_d = typeof blockchain_external_1.IBlockchainExternal !== "undefined" && blockchain_external_1.IBlockchainExternal) === "function" ? _d : Object])
], TransferRepository);


/***/ }),

/***/ 966:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.doSign = exports.getSignature = exports.buildId = exports.getAttachmentBytes = exports.getRecipientBytes = exports.getFeeBytes = exports.getAmountBytes = exports.getTimestampBytes = exports.getFeeAssetIdBytes = exports.getAssetIdBytes = exports.stringToByteArray = exports.getPublicKeyBytes = exports.getAssetTransferTxTypeBytes = void 0;
const ts_lib_crypto_1 = __webpack_require__(18);
const axlsign = __webpack_require__(958);
const blockchain_enum_1 = __webpack_require__(777);
const base58StringToByteArray = (base58String) => {
    const decoded = (0, ts_lib_crypto_1.base58Decode)(base58String);
    const result = [];
    for (let i = 0; i < decoded.length; ++i) {
        result.push(decoded[i]);
    }
    return result;
};
const getAssetTransferTxTypeBytes = (type = blockchain_enum_1.BlockchainTransactionsTypeEnum.TRANSFER) => {
    return [type];
};
exports.getAssetTransferTxTypeBytes = getAssetTransferTxTypeBytes;
const getPublicKeyBytes = (publicKey) => {
    return base58StringToByteArray(publicKey);
};
exports.getPublicKeyBytes = getPublicKeyBytes;
const stringToByteArray = (str) => {
    const bytes = new Array(str.length);
    for (let i = 0; i < str.length; i++) {
        bytes[i] = str.charCodeAt(i);
    }
    return bytes;
};
exports.stringToByteArray = stringToByteArray;
const getAssetIdBytes = (assetId, mandatory = null) => {
    if (mandatory) {
        return base58StringToByteArray(assetId);
    }
    else {
        return assetId ? [1].concat(base58StringToByteArray(assetId)) : [0];
    }
};
exports.getAssetIdBytes = getAssetIdBytes;
const getFeeAssetIdBytes = (feeAssetId) => {
    return (0, exports.getAssetIdBytes)(feeAssetId);
};
exports.getFeeAssetIdBytes = getFeeAssetIdBytes;
const getTimestampBytes = (timestamp) => {
    return longToByteArray(timestamp);
};
exports.getTimestampBytes = getTimestampBytes;
const longToByteArray = (value) => {
    const bytes = new Array(7);
    for (let k = 7; k >= 0; k--) {
        bytes[k] = value & 255;
        value = value / 256;
    }
    return bytes;
};
const getAmountBytes = (amount) => {
    return longToByteArray(amount);
};
exports.getAmountBytes = getAmountBytes;
const getFeeBytes = (fee) => {
    return longToByteArray(fee);
};
exports.getFeeBytes = getFeeBytes;
const getRecipientBytes = (recipient) => {
    return base58StringToByteArray(recipient);
};
exports.getRecipientBytes = getRecipientBytes;
const shortToByteArray = (value) => {
    return int16ToBytes(value, true);
};
const byteArrayWithSize = (byteArray) => {
    const result = shortToByteArray(byteArray.length);
    return result.concat(byteArray);
};
const getAttachmentBytes = (attachment) => {
    return byteArrayWithSize(attachment);
};
exports.getAttachmentBytes = getAttachmentBytes;
const int16ToBytes = function (x, opt_bigEndian) {
    return intToBytes(x, 2, 65535, opt_bigEndian);
};
const intToBytes = function (x, numBytes, unsignedMax, opt_bigEndian) {
    const signedMax = Math.floor(unsignedMax / 2);
    const negativeMax = (signedMax + 1) * -1;
    if (x != Math.floor(x) || x < negativeMax || x > unsignedMax) {
        throw new Error(x + ' is not a ' + numBytes * 8 + ' bit integer');
    }
    const bytes = [];
    let current;
    const numberType = x >= 0 && x <= signedMax ? 0 : x > signedMax && x <= unsignedMax ? 1 : 2;
    if (numberType == 2) {
        x = x * -1 - 1;
    }
    for (let i = 0; i < numBytes; i++) {
        if (numberType == 2) {
            current = 255 - (x % 256);
        }
        else {
            current = x % 256;
        }
        if (opt_bigEndian) {
            bytes.unshift(current);
        }
        else {
            bytes.push(current);
        }
        if (numberType == 1) {
            x = Math.floor(x / 256);
        }
        else {
            x = x >> 8;
        }
    }
    return bytes;
};
const buildId = (transactionBytes) => {
    const hash = (0, ts_lib_crypto_1.blake2b)(new Uint8Array(transactionBytes));
    return (0, ts_lib_crypto_1.base58Encode)(hash);
};
exports.buildId = buildId;
const getSignature = (data, sender) => {
    const SenderPrivateKey = (0, ts_lib_crypto_1.base58Decode)(sender.privateKey);
    return (0, exports.doSign)(SenderPrivateKey, data);
};
exports.getSignature = getSignature;
const doSign = (privateKey, dataToSign) => {
    const signature = axlsign.sign(privateKey, new Uint8Array(dataToSign));
    return (0, ts_lib_crypto_1.base58Encode)(signature);
};
exports.doSign = doSign;


/***/ }),

/***/ 993:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-cognito-identity-provider");

/***/ }),

/***/ 330:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-sqs");

/***/ }),

/***/ 563:
/***/ ((module) => {

module.exports = require("@nestjs/common");

/***/ }),

/***/ 428:
/***/ ((module) => {

module.exports = require("@nestjs/config");

/***/ }),

/***/ 781:
/***/ ((module) => {

module.exports = require("@nestjs/core");

/***/ }),

/***/ 522:
/***/ ((module) => {

module.exports = require("@nestjs/typeorm");

/***/ }),

/***/ 18:
/***/ ((module) => {

module.exports = require("@waves/ts-lib-crypto");

/***/ }),

/***/ 938:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 958:
/***/ ((module) => {

module.exports = require("axlsign");

/***/ }),

/***/ 818:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 829:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 132:
/***/ ((module) => {

module.exports = require("typeorm");

/***/ }),

/***/ 903:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 982:
/***/ ((module) => {

module.exports = require("crypto");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.handler = void 0;
exports.createInstance = createInstance;
const core_1 = __webpack_require__(781);
const dashboard_transfer_assets_module_1 = __webpack_require__(615);
const transfer_asset_user_case_1 = __webpack_require__(67);
async function createInstance() {
    try {
        const server = await core_1.NestFactory.createApplicationContext(dashboard_transfer_assets_module_1.DashboardTransferAssetsModule, {
            logger: ['error', 'warn', 'log', 'debug'],
        });
        return server.get(transfer_asset_user_case_1.ITransferAssetUseCase);
    }
    catch (error) {
        console.error('Failed to create application context:', error);
        throw error;
    }
}
const handler = async (event) => {
    try {
        const instance = await createInstance();
        console.log('[Handler] - start transfer assets.');
        await instance.execute(event);
    }
    catch (error) {
        console.error(error);
    }
};
exports.handler = handler;

})();

var __webpack_export_target__ = exports;
for(var __webpack_i__ in __webpack_exports__) __webpack_export_target__[__webpack_i__] = __webpack_exports__[__webpack_i__];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=handler.js.map